$(function() {
    $('#btnLogin').click(function(e) {
        console.log('Button was clicked');
        console.log($('form'));
        console.log($('form').serialize());
        $.ajax({
            url: '/loginCheck',
            data: $('form').serialize(),
            type: 'POST',
            dataType: "jsonp",
            success: function(response) {
                console.log(response);
                if(data){
                    if(data.error){
                        $('#resMessage').html(data.error);
                        return false;
                    }
                    else if(data.message){
                        $('#resMessage').html(data.message);
                        return false;
                    }
                    else{
                        window.location.href = "/"+data.url;
                    }
                }
            },
            error: function(error) {
                console.log(error);
            }
        });
    });
});