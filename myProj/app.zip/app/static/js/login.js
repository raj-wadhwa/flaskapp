$(function() {
    $('#btnLogin').click(function() {
        console.log('Button was clicked');
        $.ajax({
            url: '/loginCheck',
            data: $('form').serialize(),
            type: 'POST',
            success: function(response) {
                console.log(response);
                // if(response.data)
                // window.location.href = "/"+response;
            },
            error: function(error) {
                console.log(error);
            }
        });
    });
});