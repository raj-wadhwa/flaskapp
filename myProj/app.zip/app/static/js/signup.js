$(function() {
    $('#btnSignUp').click(function() {
 
        $.ajax({
            url: '/registration',
            data: $('form').serialize(),
            type: 'POST',
            success: function(response) {
                console.log(response);
                if(response.data)
                window.location.href = "/"+response;
            },
            error: function(error) {
                console.log(error);
            }
        });
    });
});