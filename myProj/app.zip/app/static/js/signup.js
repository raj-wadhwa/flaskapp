$(function() {
    $('#btnSignUp').click(function() {
        $('#resMessage').html('');
        console.log($('form'));
        console.log($('form').serialize());
        $.ajax({
            url: '/registration',
            data: $('form').serialize(),
            type: 'POST',
            success: function(response) {
                console.log(response);
                var data = JSON.parse(response);
                if(data && data.error){
                    $('#resMessage').html(data.error)
                }
                else{
                    window.location.href = "/"+data.url;    
                }
            },
            error: function(error) {
                $('#resMessage').html(error)
            }
        });
    });
});