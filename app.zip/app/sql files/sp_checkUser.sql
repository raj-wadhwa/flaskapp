CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_checkUser`( p_username varchar(25),
  P_password varchar(200))
begin
 if (Select exists(select count(*) from customer where username=p_username and password-p_password)) then
 select 'Logged -in';
  else
   select 'Usenae doesn exist. Please sign up';
 end if;
end