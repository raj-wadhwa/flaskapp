from flask import Flask, flash, render_template, json, request, url_for, redirect, session
from flaskext.mysql import MySQL
from wtforms import Form, BooleanField, TextField, PasswordField, StringField, validators, RadioField
from werkzeug import generate_password_hash, check_password_hash
import datetime
import sys
import traceback

app = Flask(__name__)
mysql = MySQL()

# MySQL configurations
app.config['MYSQL_DATABASE_USER'] = 'root'
app.config['MYSQL_DATABASE_PASSWORD'] = 'heena'
app.config['MYSQL_DATABASE_DB'] = 'cs6400_fa17_team032'
app.config['MYSQL_DATABASE_HOST'] = 'localhost'
mysql.init_app(app)
conn = mysql.connect()

# Definition of all routes

# class LoginForm(Form):
#     username = TextField('Username')
#     password = PasswordField('Password')

# loginForm = LoginForm()

@app.route('/login')
def main():
    return render_template('login.html')

@app.route('/showRegistration')
def showRegistration():
    return render_template('registration.html')

@app.route('/customerMainMenu')
def customerMainMenu():
    return render_template('customerMainMenu.html')

@app.route('/viewprofile')
def viewprofile():
    return render_template('profile.html')

@app.route('/checkToolAvailibility')
def checkToolAvailibility():
    return render_template('checkToolAvailability.html')

@app.route('/makeReservation')
def makeReservation():
    return render_template('makeReservation.html')


@app.route('/logincheck', methods=['GET'])
def logincheck():
    # create user code will be here !!
    # read the posted values from the UI
    #_name = request.form['inputName']
    _email = request.form['inputEmail']
    _password = request.form['inputPassword']
    # validate the received values
    if _email and _password:
        cursor = conn.cursor()
        try:
            cursor.callproc('sp_checkUser',(_email,_password))
            data = cursor.fetchall()
            if len(data) is 0:
                conn.commit()
                return json.dumps({'message':'User Logged In successfully !'})
            else:
                return json.dumps({'error':'Username/Password is wrong'})
        except :
            _, err, _ = sys.exc_info()
            return json.dumps({'error':err.args[1]})
        
        return json.dumps({'html':'<span>All fields good !!</span>'})
        # json.dumps({'result conn': conn})
    else:
        return json.dumps({'html':'<span>Enter the required fields</span>'})

    #_hashed_password = generate_password_hash(_password,method='pbkdf2:sha256', salt_length=8)

    #return json.dumps({'HashedPassword': _hashed_password})

class RegistrationForm(Form):
    inputName = StringField('inputName', [validators.Length(min=4, max=25)])
    # inputMiddleName = StringField('inputMiddleName', [validators.Length(min=6, max=35)])
    inputLastName = StringField('inputLastName', [validators.Length(min=4, max=25)])
    inputUsername = TextField('inputUsername', [validators.Length(min=4, max=20)])
    inputEmail = TextField('inputEmail', [validators.Length(min=6, max=50),validators.Email()])
    inputRetypedPassword = PasswordField('inputRetypedPassword')
    inputPassword = PasswordField('inputPassword', [
        validators.Required(),
        validators.EqualTo('inputRetypedPassword', message='Passwords must match')
    ])
    radioButtonValue = RadioField('contactPhone', choices=[('None','None'),('hp','hp'),('wp','wp'),('cp','cp')])
    # radioButtonValue = RadioField('contactPhone', choices=[('hp','hp'),('wp','wp'),('cp','cp')],validators=[validators.required()])
    

   # inputHomePhone = StringField('inputHomePhone')
   # inputWorkPhone = StringField('inputWorkPhone')
   # inputCellPhone = StringField('inputCellPhone')

@app.route('/registration', methods=['POST']) 
def registration():
    form = RegistrationForm(request.form)
    form.validate()
    if request.method == 'POST' and form.validate():
        inputName = form.inputName.data
        inputLastName = form.inputLastName.data
        inputHomePhone = request.form['inputHomePhone']
        inputWorkPhone = request.form['inputWorkPhone']
        inputCellPhone = request.form['inputCellPhone']
        inputUsername = form.inputUsername.data
        inputEmail = form.inputEmail.data
        # contactPhone = form.radioButtonValue.data
        contactPhone = request.form['contactPhone']
        inputPassword = form.inputPassword.data
        #_hashed_password = generate_password_hash(inputPassword,method='pbkdf2:sha256', salt_length=8)
        # inputRetypedPassword = form.inputRetypedPassword.data
        

        if not(inputHomePhone or inputWorkPhone or inputCellPhone):
             return json.dumps({'message' : '<span>Please enter atleast one contact number.</span','inputHomePhone':inputHomePhone})
        
        # return json.dumps({'message_contactnubner':contactPhone})

        if contactPhone == form.radioButtonValue.default:
             return json.dumps({'message' : '<span>At least one number should be primary.</span'})
        
        # return json.dumps({'html':'<span>Thanks for registering !!</span>'})
        # return render_template('login.html')
        cursor = conn.cursor()
        now = datetime.datetime.now()
        # cursor.callproc('registerCustomer',(inputUsername,inputEmail,inputName,inputLastName,'',_hashed_password,'',inputWorkPhone,contactPhone,'123456789','TestCVV',now,'1234'))
        # data = cursor.fetchall()
        try:
            cursor.callproc('sp_registerCustomer',(inputUsername,inputEmail,inputName,inputLastName,'',inputPassword,'',inputWorkPhone,contactPhone,'123456789','TestCVV',now,'1234'))
            data = cursor.fetchall()
            if len(data) is 0:
                conn.commit()
            # return json.dumps({'message':'User created successfully !'})
                return json.dumps({'url':'login'})
            else:
                return json.dumps({'error':str(data[0])})
        except :
            _, err, _ = sys.exc_info()
            # sys.stderr.write("ERROR: {0}\n".format(err.args[1]))
            # sys.exit(1)
            return json.dumps({'error':err.args[1]})
    else:
        # flash("Passwords do not match")
        return json.dumps({'html':'<span>Enter the required fields</span>'})
        
        #db_session.add(user)
    # return render_template('login.html', form=form)

if __name__ == "__main__":
   app.run()