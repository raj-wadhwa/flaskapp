$(function() {
    $('#btnToolSearch').click(function(e) {
        $(destination_element).html('');
        console.log('Button was clicked');
        $(destination_element).html('');
        e.preventDefault();
        $.ajax({
            url: '/checkTool',
            // data: {
            //     'test':'data'
            // },
            // type: 'POST',
            success: function(response) {
                console.log(response);
                var data = JSON.parse(response);
                if(data){
                    if(data.error){
                        $('#resMessage').html(data.error);
                        return false;
                    }
                    else if(data.message){
                        $('#resMessage').html(data.message);
                        return false;
                    }
                    else if(data.dbres){
                        //$('#resMessage').html(data.dbres);
                        draw_a_table_from_json(data.dbres,['Email','FirstName','Username'],['email','first_name','username'],'#resMessage')
                        return true;
                    }
                    else{
                        window.location.href = "/"+data.url;
                    }
                }
            },
            error: function(error) {
                console.log(error);
            }
        });
    });
});

function draw_a_table_from_json(json_data_array, head_array, item_array, destination_element) {
    $(destination_element).html('');
    var table = '<table>';
    //TH Loop
    table += '<tr>';
    $.each(head_array, function (head_array_key, head_array_value) {
        table += '<th>' + head_array_value + '</th>';
    });
    table += '</tr>';
    //TR loop
    $.each(json_data_array, function (key, value) {

        table += '<tr>';
        //TD loop
        $.each(item_array, function (item_key, item_value) {
            table += '<td>' + value[item_value] + '</td>';
        });
        table += '</tr>';
    });
    table += '</table>';

    $(destination_element).html(table);
};